// MQTT + 舵机 + 四种传感器
// 浏览器选择“控制 ESP32”，并使用相同的主题前缀。

#include <Wire.h>
#include <MPU6050.h>
#include <HX711.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include <ESP32Servo.h>

// Wi-Fi 和 MQTT 配置
const char* WIFI_SSID     = "Wokwi-GUEST";
const char* WIFI_PASSWORD = "";
const char* MQTT_HOST     = "broker.hivemq.com";

// 改成网页上显示的主题前缀，例如 esp32lab/abcd1234。
const char* TOPIC_PREFIX = "esp32lab/demo";

// 硬件引脚
const int FSR_PIN   = 34;
const int TRIG_PIN  = 26;
const int ECHO_PIN  = 27;
const int DT_PIN    = 32;
const int SCK_PIN   = 33;
const int SERVO_PIN = 13;

// 传感器和通信对象
MPU6050 mpu;
HX711 scale;
Servo servo;
WiFiClient network;
PubSubClient client(network);

String controlTopic;
String servoTopic;
String dataTopic;

// 控制状态
bool systemStopped = false;
int servoAngle = 90;
int currentMode = 0;

// 传感器读数
float accel[3] = {0, 0, 1};
float gyro[3]  = {0, 0, 0};
float weight = 0;
int fsrValue = 0;
long distanceCm = -1;

// 采集、发布和重连计时
unsigned long lastSample  = 0;
unsigned long lastPublish = 0;
unsigned long lastConnect = 0;

// 检查输入是否为指定范围内的整数。
bool integerInRange(const String& text, int maximum, int& value) {
  if (text.length() == 0 || text.length() > 3) {
    return false;
  }

  for (unsigned int i = 0; i < text.length(); i++) {
    if (text[i] < '0' || text[i] > '9') {
      return false;
    }
  }

  value = text.toInt();
  return value <= maximum;
}

// 接收 MQTT 控制消息。
void mqttCallback(char* topic, byte* payload, unsigned int length) {
  String text;

  for (unsigned int i = 0; i < length; i++) {
    text += (char)payload[i];
  }

  text.trim();
  Serial.printf("收到 %s：%s\n", topic, text.c_str());

  int value;
  String ack;

  if (String(topic) == servoTopic) {
    if (!integerInRange(text, 180, value)) {
      Serial.println("角度需为 0–180 的整数");
      return;
    }

    servoAngle = value;
    servo.write(servoAngle);
    ack = "Servo set to " + String(servoAngle);

  } else if (String(topic) == controlTopic) {
    if (text == "stop") {
      systemStopped = true;
    } else if (text == "start") {
      systemStopped = false;
    } else if (text == "toggle") {
      systemStopped = !systemStopped;
    } else if (text.startsWith("mode ")) {
      if (!integerInRange(text.substring(5), 2, value)) {
        return;
      }

      currentMode = value;
      ack = "Mode changed to " + String(currentMode);
    } else {
      // 忽略确认消息，避免消息循环。
      return;
    }

    if (ack.length() == 0) {
      ack = systemStopped ? "System stopped" : "System started";
    }
  }

  if (ack.length()) {
    client.publish(controlTopic.c_str(), ack.c_str());
    Serial.println(ack);
  }
}

// 读取四种传感器，并根据当前模式输出到串口。
void readSensors() {
  int16_t ax, ay, az, gx, gy, gz;
  mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

  accel[0] = ax / 16384.0;
  accel[1] = ay / 16384.0;
  accel[2] = az / 16384.0;

  gyro[0] = gx / 16.4;
  gyro[1] = gy / 16.4;
  gyro[2] = gz / 16.4;

  fsrValue = analogRead(FSR_PIN);

  if (scale.is_ready()) {
    weight = scale.get_units(5);
  }

  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  unsigned long duration = pulseIn(ECHO_PIN, HIGH, 30000);
  distanceCm = duration ? duration * 0.034 / 2 : -1;

  if (currentMode != 2) {
    Serial.printf(
      "加速度 %.2f %.2f %.2f g | 角速度 %.2f %.2f %.2f °/s\n",
      accel[0], accel[1], accel[2],
      gyro[0], gyro[1], gyro[2]
    );
  }

  if (currentMode != 1) {
    const char* pressure = fsrValue < 100 ? "无压力"
                         : fsrValue < 500 ? "轻压"
                         : fsrValue < 800 ? "中压"
                                          : "重压";

    Serial.printf(
      "FSR ADC %d | %.2f V | %s | 重量 %.2f kg\n",
      fsrValue, fsrValue * 3.3 / 4095.0, pressure, weight
    );
  }

  if (currentMode == 0) {
    if (distanceCm < 0) {
      Serial.println("HC-SR04 无回波");
    } else {
      Serial.printf("距离 %ld cm\n", distanceCm);
    }
  }
}

// 将传感器读数和控制状态以 JSON 格式发布。
void publishData() {
  String distance = distanceCm < 0 ? "null" : String(distanceCm);
  char payload[512];

  snprintf(
    payload, sizeof(payload),
    "{"
      "\"accelX\":%.2f,"
      "\"accelY\":%.2f,"
      "\"accelZ\":%.2f,"
      "\"gyroX\":%.2f,"
      "\"gyroY\":%.2f,"
      "\"gyroZ\":%.2f,"
      "\"fsrValue\":%d,"
      "\"weight\":%.2f,"
      "\"distance\":%s,"
      "\"systemStopped\":%s,"
      "\"currentMode\":%d,"
      "\"servoAngle\":%d"
    "}",
    accel[0], accel[1], accel[2],
    gyro[0], gyro[1], gyro[2],
    fsrValue, weight, distance.c_str(),
    systemStopped ? "true" : "false",
    currentMode, servoAngle
  );

  if (client.publish(dataTopic.c_str(), payload)) {
    Serial.println("MQTT 数据已发送");
  }
}

void setup() {
  Serial.begin(115200);

  // MQTT 主题
  controlTopic = String(TOPIC_PREFIX) + "/control";
  servoTopic   = String(TOPIC_PREFIX) + "/servo";
  dataTopic    = String(TOPIC_PREFIX) + "/data";

  // MPU6050
  Wire.begin(21, 22);
  mpu.initialize();

  if (!mpu.testConnection()) {
    Serial.println("MPU6050 连接失败");

    while (true) {
      delay(1000);
    }
  }

  mpu.setFullScaleGyroRange(MPU6050_GYRO_FS_2000);
  mpu.setFullScaleAccelRange(MPU6050_ACCEL_FS_2);

  // HX711：Wokwi 5 kg 模型；实物请重新标定。
  scale.begin(DT_PIN, SCK_PIN);
  scale.set_scale(420.0);

  if (scale.wait_ready_timeout(2000)) {
    scale.tare();
  }

  // 压力传感器和超声波传感器
  pinMode(FSR_PIN, INPUT);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  // 舵机
  servo.setPeriodHertz(50);
  servo.attach(SERVO_PIN, 500, 2400);
  servo.write(servoAngle);

  // Wi-Fi 和 MQTT
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  client.setServer(MQTT_HOST, 1883);
  client.setCallback(mqttCallback);
  client.setBufferSize(768);
  client.setSocketTimeout(2);

  Serial.printf("主题前缀：%s\n", TOPIC_PREFIX);
}

void loop() {
  unsigned long now = millis();

  // 每 5 秒尝试重新连接 MQTT。
  if (WiFi.status() == WL_CONNECTED && !client.connected() &&
      (lastConnect == 0 || now - lastConnect >= 5000)) {
    lastConnect = now;
    String id = "esp32lab-" + WiFi.macAddress();

    if (client.connect(id.c_str())) {
      client.subscribe(controlTopic.c_str());
      client.subscribe(servoTopic.c_str());
      Serial.println("MQTT 已连接");
    }
  }

  client.loop();

  // 每 500 ms 采集一次。
  if (!systemStopped && now - lastSample >= 500) {
    lastSample = now;
    readSensors();
  }

  // 每 2 秒发布一次。暂停时上传最后的读数及暂停状态。
  if (client.connected() && now - lastPublish >= 2000) {
    lastPublish = now;
    publishData();
  }

  delay(5);
}
