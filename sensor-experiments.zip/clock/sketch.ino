#include <WiFi.h>
#include <WiFiUdp.h>
#include <NTPClient.h>
#include <ESP32Servo.h>

// Wokwi 仿真接入点；实物改为自己的 WiFi。
const char* ssid = "Wokwi-GUEST";
const char* password = "";
const int hourPin = 13;
const int minutePin = 12;
const int secondPin = 14;
Servo hourServo;
Servo minuteServo;
Servo secondServo;
WiFiUDP ntpUDP;
NTPClient timeClient(ntpUDP, "pool.ntp.org", 8 * 3600, 60000);
unsigned long lastUpdate = 0;
unsigned long lastSyncAttempt = 0;
bool synchronized = false;

void setup() {
  Serial.begin(115200);
  Serial.println("ESP32 网络舵机时钟初始化中...");
  hourServo.setPeriodHertz(50);
  minuteServo.setPeriodHertz(50);
  secondServo.setPeriodHertz(50);
  hourServo.attach(hourPin, 500, 2400);
  minuteServo.attach(minutePin, 500, 2400);
  secondServo.attach(secondPin, 500, 2400);
  hourServo.write(90);
  minuteServo.write(90);
  secondServo.write(90);
  WiFi.begin(ssid, password);
  Serial.print("正在连接 WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print('.');
  }
  Serial.println("\nWiFi 已连接");
  Serial.println(WiFi.localIP());
  timeClient.begin();
}

void loop() {
  // 首次同步失败时每 5 秒重试，成功后由 NTPClient 每 60 秒校时。
  if (WiFi.status() == WL_CONNECTED &&
      (lastSyncAttempt == 0 || millis() - lastSyncAttempt >= 5000)) {
    lastSyncAttempt = millis();
    if (timeClient.update()) synchronized = true;
  }
  if (millis() - lastUpdate >= 1000) {
    lastUpdate = millis();
    if (!synchronized) {
      Serial.println("等待 NTP 校时，舵机保持中位...");
    } else {
      const int hours = timeClient.getHours();
      const int minutes = timeClient.getMinutes();
      const int seconds = timeClient.getSeconds();
      // 教程的 0–180° 映射；12 点与 0 点均回到周期起点。
      const int hourAngle = map((hours % 12) * 60 + minutes, 0, 720, 0, 180);
      const int minuteAngle = map(minutes * 60 + seconds, 0, 3600, 0, 180);
      const int secondAngle = map(seconds, 0, 60, 0, 180);
      hourServo.write(hourAngle);
      minuteServo.write(minuteAngle);
      secondServo.write(secondAngle);
      Serial.printf("时间: %02d:%02d:%02d | 舵机角度 - 时: %d°, 分: %d°, 秒: %d°\n",
                    hours, minutes, seconds, hourAngle, minuteAngle, secondAngle);
    }
  }
  delay(1);
}
